
public class Customer {
    String name="小明";

    int wantRua;
localDate localDate=new localDate();




    @Override
    public String toString(){
        return "顾客姓名:"+name+",想rua猫次数:"+wantRua+",到店时间:"+localDate.localDate;
    }


}

class localDate{
 String localDate="今日";



    }

