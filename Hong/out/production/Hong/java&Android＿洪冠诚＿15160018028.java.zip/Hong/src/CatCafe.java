import java.lang.*;
public interface CatCafe {
     void purchase(String name,double price);
    void treat(String customer);
     void rest();
}
