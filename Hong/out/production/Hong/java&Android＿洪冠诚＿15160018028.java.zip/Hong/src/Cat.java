public abstract class Cat {
    String name;
    int age;
    String sex;
    double price;

    public Cat(String name,int age,String sex,double price){
        this.name=name;
        this.age=age;
        this.sex=sex;
        this.price=price;

    }

    public abstract String toString();
}
