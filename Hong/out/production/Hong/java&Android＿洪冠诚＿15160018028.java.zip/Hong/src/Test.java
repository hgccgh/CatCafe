import java.util.ArrayList;
import java.util.Date;
public class Test {
        public static void main(String[] args) {
            MyCatCafe myCatCafe=new MyCatCafe();

            ArrayList<String> restock =new ArrayList<>();

            try {
                new MyCatCafe().purchase("OrangeCat",200);
                restock.add("OrangeCat");
            } catch (InsufficientBalanceException e) {
                e.printStackTrace();
                System.out.println("余额不足，无法购买OrangeCat");
            }


            try {
                new MyCatCafe().purchase("BlackCat",350);
                restock.add("BlackCat");
            } catch (InsufficientBalanceException e) {
                e.printStackTrace();
                System.out.println("余额不足，无法购买BlackCat");
            }

            System.out.println("所购买的猫的种类为:"+restock);
            ArrayList<String> memory =new ArrayList<>();
            memory.add("小明");
            myCatCafe.treat("小明");
            System.out.println("今日所到访的顾客姓名为:"+memory);
            Date date=new Date();
            System.out.printf("到店时间:%tF%n",date);
            myCatCafe.rest();
        }

}
